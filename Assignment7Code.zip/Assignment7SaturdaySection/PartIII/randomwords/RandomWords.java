package randomwords;

import java.util.Random;
import java.util.List;
import javafx.util.Pair;

public class RandomWords {

	private String filename;
	/* choose ArrayList<String> or String[] to store the words */
	
	public RandomWords() {

	}
	
	public RandomWords(String filename) {
		
	}
	
	public static int levenshteinDistance(String word1, String word2) {
		return 0;
	}
	
	public List<Pair<String, String>> sortedPairsComparator() {
		
		return null;
	}
	
	public List<Pair<String, String>> sortedPairsLambda() {
		
		return null;
	}
	
	public static void main(String[] args) {
		
	}
}
