package edu.nyu.cs9053.midterm.hierarchy;

public abstract class WinterSportPlayer {

	public String getName() {
		
		return null;
	}
	
	public int getAge() {
		
		return -1;
	}
}
